<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of clientDAO
 *
 * @author oscar
 */
class clientDAO extends Model{
    
    
    
    public function getFieldsToRemove() {
        
    }
    
    public function getPrimaryKey() {
        
    }
    
    public function getTableName() {
        
    }
    
    public function getConnection() {
        
    }
    
    public function getFields() {
        
    }
    
}
