<?php 
$root="";
if(!file_exists("class/Model.php")){
    $root = "../../";
}

?>
<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Wolves </title>
    <!-- Windows 8 Tiles -->
    <meta name="msapplication-TileColor" content="#FFFFFF">
    <!-- ****** faviconit.com favicons ****** -->
    <link rel="stylesheet" type="text/css" href="<?= $root ?>css/style.css">
    <link rel="stylesheet" type="text/css" href="<?= $root ?>css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?= $root ?>css/animate.min.css">
    <link rel="stylesheet" href="<?= $root ?>css/picto-foundry-emotions.css">
    <link rel="stylesheet" href="<?= $root ?>css/picto-foundry-household.css">
    <link rel="stylesheet" href="<?= $root ?>css/picto-foundry-shopping-finance.css">
    <link rel="stylesheet" href="<?= $root ?>css/picto-foundry-general.css">
    <link href="<?= $root ?>css/font-awesome.min.css" rel="stylesheet">
  </head>
  <body>
    <div class="pushWrapper">
      <!-- Header (shown on mobile only) -->
      
      <!-- Main -->
      <main id="mainContent" name="mainContent">
        <!-- FORMS -->
        <!-- INTRO -->
        
            
      