<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$lang = array(
        /* Login */
	"client_login_tittle" => "Iniciar Sesion en modulo de clientes",
	"login_user" => "Usuario",
	"login_passwd" => "Contraseña",
	"login_entrar" => "Ingresar",
        "login_registro" => "Registrarse",
    
    
	"opcion_1" => "Select",
	"opcion_2" => "Spanish",
	"opcion_3" => "English",
	"descripcion" => "Hello, this is a title in Spanish",
);