
<?php

//$menu = true;

include 'header.php';
?>

<section class="section-intro" id="section-intro" data-stellar-background-ratio="0.5"

              data-stellar-vertical-offset="0"> <a class="LC-logo" href="#/">
                <!-- span class="text">Luxury</span> --> </a>
              <div class="content">
                <div class="container-template">
                  <h1> 
                      <center><img src="images/wolvess.jpeg" width="120px" ></center>
                    <!-- <i class="step icon-diamond size-36"></i>  -->
                    <span class="seconday">Wolves Traders Company</span> 
                    <!-- <span style="font-style: italic;">Company</span>  -->
                  </h1>
                </div>
              </div>
            </section>
            <section class="timeline-part" id="timeline-part">
              <div class="content">
                <div class="container-template">
                  <div class="headergroup">
                      <h2 class="in-point"> <span class="seconday" style="font-size: 50px;">Quienes somos?</span> </h2>
                  </div>
                  <div class=" content-template"><br>
                    <p><strong>Somos un equipo de profesionales del trading. </strong></p>
                    <p>Realizamos transacciones internacionales.</p>
                    
                  </div>
                  <!--<ul class="timeline">
                    <li class="year">2012</li>
                    <li class="upper-line"> <span class="title">Founded by John Doe
                        in 2012</span> <span class="timeline-content paragraph-text">“My
                        motive in launching Luxury Homes was to create a wider
                        platform for Luxury Property Developers to better showcase
                        their work..” <strong>John Doe, FOUNDER &amp; MANAGING
                          DIRECTOR</strong> </span> </li>
                    <li class="year">2013</li>
                    <li class="upper-line"> <span class="title">2800 + people buy
                        and sell their property in a year</span> <span class="paragraph-text timeline-content">
                        The website combines a luxury apartments that gives both
                        members of where to go on a practical level to find the best
                        of the best in the world. </span> </li>
                    <li class="year">2014</li>
                    <li class="upper-line"> <span class="title">Luxury Homes
                        started their business around the globe. </span> <span class="timeline-content">
                        We have our business in 12 countries all over the world. We
                        want to spread it throughout the world. You can contribute
                        us joining the winning the team </span> </li>
                  </ul> -->
                </div>
              </div>
            </section>
        
            <!-- ONLINE STATISTICS SECTION -->
            <!--
            <section class="stastistical-part" id="stastistical-part">
              
              <div class="section-seperator">
                <div class="container-template">
                  <h2> <span class="seconday">Our</span> Services </h2>
                </div>
              </div>
              
              <div class="content">
                <div class="container-template">
                  <div class="headergroup">
                    <h2> <span class="seconday">Ranked No.1 for</span> <span>"Luxury
                        Modern Homes"</span> </h2>
                  </div>
                  <div class="intro container-template">
                    <p>Since 2012, the Luxury Homes have introduced themselves in
                      many countries:</p>
                  </div>
                  
                    
                  <div class="statistics">
                    <div class="barChart">
                      <div class="dummybar"></div>
                      <div class="bar" data-percentage="80">
                        <div class="tooltip tooltip-left">
                          <div class="tooltip-label">Buy Homes
                            <hr></div>
                          <div class="tooltip-value">$194,219 spent </div>
                        </div>
                      </div>
                      <div class="bar" data-percentage="45">
                        <div class="tooltip tooltip-topRight">
                          <div class="tooltip-label">Sell Homes
                            <hr></div>
                          <div class="tooltip-value">$154,095 Earned</div>
                        </div>
                      </div>
                      <div class="bar" data-percentage="23">
                        <div class="tooltip tooltip-right">
                          <div class="tooltip-label">Land Sell
                            <hr></div>
                          <div class="tooltip-value">$135,489 Earned</div>
                        </div>
                      </div>
                    </div>
                    
                      
                      
                      
                    <ul class="rounded-icon">
                      <li>
                        <div class="rounded-icon-icon"><i class="icon-graph-up-1 size-36"></i></div>
                        <div class="rounded-icon-value">64% </div>
                        <div class="rounded-icon-label">Total market share</div>
                      </li>
                      <li>
                        <div class="rounded-icon-icon"><i class="icon-thumbs-up-fill size-36"></i></div>
                        <div class="rounded-icon-value">95%</div>
                        <div class="rounded-icon-label">Clients have recommended us</div>
                      </li>
                      <li>
                        <div class="rounded-icon-icon"><i class="icon-bank size-36"></i></div>
                        <div class="rounded-icon-value">20</div>
                        <div class="rounded-icon-label">Banks are associated with us</div>
                      </li>
                    </ul>
                    
                      
                      
                    <div class="pieChart">
                      
                      <div class="pieChart-overlay">
                        <div class="container-template">
                          <h3> Around </h3>
                          <div class="seconday">The Globe</div>
                        </div>
                      </div>
                      <div class="pie-section " data-start="0" data-degrees="141.22">
                        <div class="pie-section-before"></div>
                      </div>
                      <div class="pie-section " data-start="141.22" data-degrees="69.69">
                        <div class="pie-section-before"></div>
                      </div>
                      <div class="pie-section " data-start="210.91" data-degrees="25.27">
                        <div class="pie-section-before"></div>
                      </div>
                      <div class="pie-section " data-start="236.18" data-degrees="14.52">
                        <div class="pie-section-before"></div>
                      </div>
                      <div class="pie-section " data-start="250.7" data-degrees="109.3">
                        <div class="pie-section-before"></div>
                      </div>
                      <div class="pie-section-labels">
                        <div class="pie-section-label tooltip " data-x="0.943280616635"

                          data-y="-0.331996503416">
                          <div class="tooltip-label">Europe</div>
                          <div class="tooltip-value">21,222</div>
                        </div>
                        <div class="pie-section-label tooltip " data-x="0.0686247285818"

                          data-y="0.997642544515">
                          <div class="tooltip-label">North America</div>
                          <div class="tooltip-value">10,473</div>
                        </div>
                        <div class="pie-section-label tooltip " data-x="-0.688924071028"

                          data-y="0.724833514925">
                          <div class="tooltip-label">Australia</div>
                          <div class="tooltip-value">3,797</div>
                        </div>
                        <div class="pie-section-label tooltip " data-x="-0.894466613728"

                          data-y="0.447134741355">
                          <div class="tooltip-label">Asia</div>
                          <div class="tooltip-value">2,182</div>
                        </div>
                        <div class="pie-section-label tooltip " data-x="-0.815633003474"

                          data-y="-0.578569618666">
                          <div class="tooltip-label">Africa</div>
                          <div class="tooltip-value">16,425</div>
                        </div>
                      </div>
                    </div>
                    
                    
                    
                    <ul class="pieChart-list">
                      <li><span class="label">Europe</span><span class="value">21,222
                          Acres</span></li>
                      <li><span class="label">North America</span><span class="value">10,473
                          Acres</span></li>
                      <li><span class="label">Australia</span><span class="value">3,797
                          Acres</span></li>
                      <li><span class="label">Asia</span><span class="value">2,182
                          Acres</span></li>
                      <li><span class="label">Africa</span><span class="value">16,425
                          Acres</span></li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
            -->
            
            
            
            
            <!-- TESTIMONIALS SECTION -->
            
            <section class="testimonials-part" id="testimonials-part">
              
              <div class="testimonials-part-section-seperator">
                <div class="container-template">
                  <h2> <span class="seconday">Que Dicen</span> Nuestros Inversores </h2>
                  <div class="testimonials-container">
                    <ul class="testimonials testimonials-wrapper">
                      <li class="testimonials-slide"> <span class="testimonial-text">Estoy muy contento con los rendimientos, Quiero invertir mas.</span>
                        <span class="testimonial-author">Andres Parra</span> </li>
                      <li class="testimonials-slide"> <span class="testimonial-text">Los recomiendo totalmente, son confiables y serios y cumplidos.</span> 
                          <span class="testimonial-author">Ofelia Vanegas</span> </li>
                      <li class="testimonials-slide"> <span class="testimonial-text">Excelente inversion, las ganancias son extraordinarias.</span> 
                          <span class="testimonial-author">Felipe Gomez</span> </li>
                      <li class="testimonials-slide"> <span class="testimonial-text">Al principio no creia, pero un amigo me insistio tanto hasta que inverti, ahora estoy convenciendo a otros amigos, realmente me convencio, estoy feliz!.</span> 
                          <span class="testimonial-author">Andrea Vargas</span> </li>
                    </ul>
                  </div>
                  <div class="testimonials-pagination"></div>
                </div>
              </div>
            </section>
            <!--
            <section class="membership-part" id="membership-part">
              
              <div class="membership-part-section-seperator" data-stellar-background-ratio="0.5"

                data-stellar-vertical-offset="0">
                <div class="container-template"> <img style="margin: auto;" src="images/keys.png"

                    alt="keys">
                  <div class="headergroup">
                    <h2> <span class="seconday">Get</span> <span>A Home</span> </h2>
                  </div>
                  <div class="content-template">
                    <p>Luxury operates on a membership basis. All customers who wish
                      to be featured by Luxury need to secondayscribe to an annual
                      membership once their application has been approved to meet
                      our standard. We aim to feature only the best of the best.</p>
                    <p>If you would like to be considered for membership, please
                      contact us.</p>
                  </div>
                  <br>
                  <button type="button" class="form-btn semibold">Get A Home</button>
                </div>
              </div>
            </section>
            -->
            <!--
            <section class="featured-part" id="featured-part">
              
              <div class="content">
                <div class="container-template">
                  <div class="headergroup">
                    <h2> <span class="seconday">Top</span> <span>Featured</span> </h2>
                  </div>
                  <br>
                  <div class="intro content-template">
                    <p>Luxury Homes operates on in over 155 countries all over the
                      world: <strong>Apartments</strong>, <strong>Condos</strong>
                      and <strong>Mansions</strong>.</p>
                  </div>
                  <br>
                  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    
                    <ol class="carousel-indicators">
                      <li data-target="#carousel-example-generic" data-slide-to="0"

                        class="active"><br>
                      </li>
                      <li data-target="#carousel-example-generic" data-slide-to="1"><br>
                      </li>
                      <li data-target="#carousel-example-generic" data-slide-to="2"><br>
                      </li>
                    </ol>
                    
                    <div class="carousel-inner">
                      <div class="item active"> <img src="images/pricing.jpg" alt="...">
                        <div class="carousel-caption"> </div>
                      </div>
                      <div class="item"> <img src="images/pricing.jpg" alt="...">
                        <div class="carousel-caption"> </div>
                      </div>
                      <div class="item"> <img src="images/pricing.jpg" alt="...">
                        <div class="carousel-caption"> </div>
                      </div>
                    </div>
                    <a class="left carousel-control" href="#carousel-example-generic"

                      role="button" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>
                    </a> <a class="right carousel-control" href="#carousel-example-generic"

                      role="button" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>
                    </a> </div>
                </div>
              </div>
            </section>
            -->
            <br><br><br><br>
            <section class="tips-part" id="tips-part">
              <div class="section-seperator">
                <div class="container-template">
                  <h2> <span class="seconday">Tips</span> Importantes </h2>
                </div>
              </div>
              
              <div class="content">
                <div class="container-template">
                  <h2> Tips Importantes </h2>
                  <div class="content-template">
                    <ul>
                      <li> <i class="icon-task-check"></i> Puedes comprar todos los paquetes que quieras. </li>
                      <li> <i class="icon-task-check"></i> Obtendras excelente rentabilidad mensual garantizada. </li>
                      <li> <i class="icon-task-check"></i> Despues de registrarte, podras acceder al panel de control de tu cuenta. </li>
                      <li> <i class="icon-task-check"></i> Si invitas a tus amigos, podras ganar cuando ellos inviertan. </li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>
            
            
            
            
            
            <!--
            <section class="pricing-part" id="pricing-part">
              
              <div class="section-seperator">
                <div class="container-template">
                  <h2> <span class="seconday">Our</span> Pricing </h2>
                </div>
              </div>
              
              <div class="content">
                <div class="container-template">
                  
                  <ul class="pricing-menu">
                    <li class="selected"><a href="#">On Sale</a></li>
                    <li><a href="#">Recently Sold</a></li>
                    <li><a href="#">For Rent</a></li>
                  </ul>
                  
                  <div class="pricing-container">
                    <div class="pricing-wrapper">
                      <div class="pricing-slide">
                        <div class="headergroup">
                          <h3> <span>Sale</span> <span class="seconday">Annual
                              Cost</span> <span class="super-seconday">$587,000</span>
                          </h3>
                        </div>
                        <div class="pricing-slide-content content-template">
                          <p>Our Diamond Membership Package</p>
                          <ul>
                            <li class="pricing-slide-text"> <i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                          </ul>
                          <p>&nbsp;</p>
                        </div>
                      </div>
                      <div class="pricing-slide">
                        <div class="headergroup">
                          <h3> <span>Sold</span> <span class="seconday">Annual
                              Cost</span> <span class="super-seconday">$358,000</span>
                          </h3>
                        </div>
                        <div class="pricing-slide-content content-template">
                          <p>Our premium Membership Package</p>
                          <ul>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                          </ul>
                          <p>&nbsp;</p>
                        </div>
                      </div>
                      <div class="pricing-slide">
                        <div class="headergroup">
                          <h3> <span>Rent</span> <span class="seconday">Annual
                              Cost</span> <span class="super-seconday">$18,000</span>
                          </h3>
                        </div>
                        <div class="pricing-slide-content content-template">
                          <p>Our great Membership Package</p>
                          <ul>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                            <li class="pricing-slide-text"><i class="icon-compose"></i>
                              Lorem ipsum dolor sit amet, consectetur adipisicing
                              elit. Soluta, explicabo, Luxury.</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            -->
            
            
            
            <!--
            <section class="events-part" id="events-part">
              
              <div class="section-seperator">
                <div class="container-template">
                  <h2> <span class="seconday">Upcoming</span> Events </h2>
                </div>
              </div>
              
              <div class="content">
                <div class="container-template">
                  
                  <ul class="events-list">
                    <li class="event-titles">
                      <div class="event-title">Event</div>
                      <div class="event-title">Date</div>
                      <div class="event-title">Location</div>
                    </li>
                    <li>
                      <div class="event-text">
                        <div class="event-details content-template">
                          <h4 class="event-title">Highbury</h4>
                          <div class="event-date"> 08/09/2015 </div>
                          <div class="event-location"> London Rd. 46 Waterloo Road.
                            NW1 5QT </div>
                        </div>
                        <div class="event-description content-template">devious
                          Semikoli. Semantics, a large language ocean. A small river
                          named Duden flows by their place and supplies it with the
                          necessary regelialia. It is a paradisematic country, in
                          which roasted parts of sentences fly into your mouth. </div>
                      </div>
                      <div class="event-image"> <img src="images/lambo2copy.jpg" alt="your text">
                      </div>
                    </li>
                    <li>
                      <div class="event-text">
                        <div class="event-details content-template">
                          <h4 class="event-title">Gordon Hague</h4>
                          <div class="event-date"> 29/05/2014 </div>
                          <div class="event-location"> Unit 68 69 Royal Hospital
                            Road London SW3 4HP </div>
                        </div>
                        <div class="event-description content-template">Far far
                          away, behind the word mountains, far from the countries
                          Vokalia and Consonantia, there live the blind texts.
                          Separated they live in Bookmarksgrove right at the coast
                          of the Semantics, a large language ocean. A small river
                          named Duden of Luxury. </div>
                      </div>
                      <div class="event-image"> <img src="images/appartmentcopy.jpg"

                          alt="your text"> </div>
                    </li>
                    <li>
                      <div class="event-text">
                        <div class="event-details content-template">
                          <h4 class="event-title">devious Semikoli</h4>
                          <div class="event-date"> 09/07/2013 </div>
                          <div class="event-location"> Rocking Palace, 22 Happiness
                            Hill Way. </div>
                        </div>
                        <div class="event-description content-template">Far far
                          away, behind the word mountains, far from the countries
                          Vokalia and Consonantia, there live the blind texts.
                          Separated they live in Bookmarksgrove right at the coast
                          of the Semantics, a large language ocean. A small river
                          named Duden</div>
                      </div>
                      <div class="event-image"> <img src="images/intro_bgcopy.jpg"

                          alt="your text here"> </div>
                    </li>
                    <li>
                      <div class="event-text">
                        <div class="event-details content-template">
                          <h4 class="event-title">47 Chandos Place</h4>
                          <div class="event-date"> 29/09/2019 </div>
                          <div class="event-location"> 47 Chandos Place Covent
                            Garden London WC2N 4HS Covent Garden, Strand </div>
                        </div>
                        <div class="event-description content-template">Far far
                          away, behind the word mountains, far from the countries
                          Vokalia and Consonantia, there live the blind texts.
                          Separated they live in Bookmarksgrove right at the coast
                          of the Semantics, a large language ocean. A small river
                          named Duden </div>
                      </div>
                      <div class="event-image"> <img src="images/brand-copyy.jpg" alt="your text">
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </section>
            -->
            
            
            
            <!-- FOUNDERS & TEAM SECTION-->
            <section class="section-team" id="section-team">
              <!-- Content -->
              <div class="content">
                <div class="container-template">
                  <div class="headergroup">
                    <h2> <span class="seconday">Meet our</span> <span>Fundador</span>
                    </h2>
                  </div>
                  <!-- Team Members List -->
                  <ul class="team-members">
                    <li>
                      <div class="team-member-image"> <img src="images/Reza.jpg" alt="yours alone">
                      </div>
                      <h3 class="team-member-title"> <span class="seconday">Ivan Contreras</span> </h3>
                      <div class="team-member-text content-template">
                        <p>Fundador de Wolves Traders Company. Mas de 4 años realizando Trading de manera profesional.</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </section>
            <section class="contact-form" id="contact-form">
              <div class="headergroup">
                <h2> <span class="secondary">Contactenos</span></h2>
              </div>
              <div class="container">
                <div class="inner contact">
                  <!-- Form Area -->
                  <div class="contact-form">
                    <!-- Form --> <br>
                    <form id="contact-us" method="post" action="contact.php">
                      <!-- Left Inputs -->
                      <div class="col-xs-6 ">
                        <!-- Name --> <br>
                        <input name="name" id="name" required="required" class="form" placeholder="Nombre" type="text">
                        <!-- Email --> <input name="email" id="email" required="required"

                          class="form" placeholder="Correo" type="email">
                        <!-- secondayject --> <input name="asunto" id="asunto"

                          required="required" class="form" placeholder="Asunto"

                          type="text"> </div>
                      <!-- End Left Inputs -->
                      <!-- Right Inputs -->
                      <div class="col-xs-6">
                        <!-- Message --> <br>
                        <textarea name="message" id="message" class="form textarea" placeholder="Mensaje"></textarea> </div>
                      <!-- End Right Inputs -->
                      <!-- Bottom secondaymit -->
                      <div class="relative fullwidth col-xs-12">
                        <!-- Send Button --> <button type="button" id="secondaymit"

                          name="secondaymit" class="form-btn semibold">Enviar</button>
                      </div>
                      <!-- End Bottom secondaymit -->
                      <!-- Clear -->
                      <div class="clear"></div>
                    </form>
                    <!-- Your Mail Message -->
                    <div class="mail-message-area">
                      <!-- Message -->
                      <div class="alert gray-bg mail-message not-visible-message"> <strong>Thank
                          You !</strong> Your email has been delivered. </div>
                    </div>
                  </div>
                </div>
                <!-- End Contact Form Area --> </div>
              <!-- End Inner --> <br>
            </section>
            <footer class="pageFooter">
              <div class="btnContainer"> <a class="gc-link" href="#" target="_blank"><i

                    class="icon-handcrafted"></i></a> </div>
              <div class="btnContainer"> <a class="LC-logo" href="#/"> <i class="icon-LClogo"></i>
                </a> </div>
            </footer>

        

<?php
include 'footer.php';
?>            